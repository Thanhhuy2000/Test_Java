package com.example.De2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class De2Application {

	public static void main(String[] args) {
		SpringApplication.run(De2Application.class, args);
	}

}
